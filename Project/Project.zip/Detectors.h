#ifndef _DETECTORS_INCL_GUARD
#define _DETECTORS_INCL_GUARD

#include "Tracker.h"
#include "ECalorimeter.h"
#include "HCalorimeter.h"
#include "Muon_chamber.h"

#endif